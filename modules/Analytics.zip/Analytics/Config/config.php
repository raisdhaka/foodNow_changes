<?php

return [
    'name' => 'Analytics'
];
